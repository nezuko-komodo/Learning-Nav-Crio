package com.crio.LearningNavigator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningNavigatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
