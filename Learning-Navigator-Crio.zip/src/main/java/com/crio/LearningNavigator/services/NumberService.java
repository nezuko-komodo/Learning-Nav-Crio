package com.crio.LearningNavigator.services;

public interface NumberService {

    String getNumberFact(int num);
    
}
